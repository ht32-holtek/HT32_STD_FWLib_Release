/*********************************************************************************************************//**
 * @file    ht32f490x1.h
 * @version $Rev:: 84          $
 * @date    $Date:: 2025-05-12 #$
 * @brief   ht32f490x1 header file
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

#ifndef __HT32F490x1_H
#define __HT32F490x1_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined (__CC_ARM)
 #pragma anon_unions
#endif

/** @addtogroup CMSIS
  * @{
  */

/** @addtogroup HT32F490x1
  * @{
  */

/** @addtogroup Library_configuration_section
  * @{
  */

/**
  * tip: to avoid modifying this file each time you need to switch between these
  *      devices, you can define the device in your toolchain compiler preprocessor.
  */

#if !defined (USE_HT32F49041_64LQFP) && !defined (USE_HT32F49041_48LQFP) && !defined (USE_HT32F49041_48QFN)   && \
    !defined (USE_HT32F49041_32LQFP) && !defined (USE_HT32F49041_32QFN)  && !defined (USE_HT32F49041_20TSSOP) && \
    !defined (USE_HT32F49031_64LQFP) && !defined (USE_HT32F49031_48LQFP) && !defined (USE_HT32F49031_48QFN)   && \
    !defined (USE_HT32F49031_32LQFP) && !defined (USE_HT32F49031_32QFN)  && !defined (USE_HT32F49031_20TSSOP)

    #error "Please select first the target device used in your application (in ht32f490x1.h file)"
#endif

#if defined (USE_HT32F49041_64LQFP) || defined (USE_HT32F49041_48LQFP) || defined (USE_HT32F49041_48QFN)   || \
    defined (USE_HT32F49041_32LQFP) || defined (USE_HT32F49041_32QFN)  || defined (USE_HT32F49041_20TSSOP) || \
    defined (USE_HT32F49031_64LQFP) || defined (USE_HT32F49031_48LQFP) || defined (USE_HT32F49031_48QFN)   || \
    defined (USE_HT32F49031_32LQFP) || defined (USE_HT32F49031_32QFN)  || defined (USE_HT32F49031_20TSSOP)

    #define USE_HT32F490x1
    #define LIBCFG_MAX_SPEED                (96000000)
    #define LIBCFG_FLASH_PAGESIZE           (1024)
    #define LIBCFG_RAM_SIZE                 (1024 * 20)
#endif

/**
  * define with package
  */
#if defined (USE_HT32F49041_64LQFP) || defined (USE_HT32F49031_64LQFP)

    #define USE_HT32F490x1_64
#endif

#if defined (USE_HT32F49041_48LQFP) || defined (USE_HT32F49041_48QFN) || defined (USE_HT32F49031_48LQFP) || \
    defined (USE_HT32F49031_48QFN)

    #define USE_HT32F490x1_48
#endif

#if defined (USE_HT32F49041_32LQFP) || defined (USE_HT32F49041_32QFN) || defined (USE_HT32F49031_32LQFP) || \
    defined (USE_HT32F49031_32QFN)

    #define USE_HT32F490x1_32
#endif

#if defined (USE_HT32F49041_20TSSOP) || defined (USE_HT32F49031_20TSSOP)

    #define USE_HT32F490x1_20
#endif

/**
  * define with memory density
  */
#if defined (USE_HT32F49031_64LQFP) || defined (USE_HT32F49031_48LQFP) || defined (USE_HT32F49031_48QFN)  ||\
    defined (USE_HT32F49031_32LQFP) || defined (USE_HT32F49031_32QFN)  || defined (USE_HT32F49031_20TSSOP)

    #define LIBCFG_FLASH_SIZE               (LIBCFG_FLASH_PAGESIZE * 32)
    #define USE_HT32F49031
#endif

#if defined (USE_HT32F49041_64LQFP) || defined (USE_HT32F49041_48LQFP) || defined (USE_HT32F49041_48QFN)  || \
    defined (USE_HT32F49041_32LQFP) || defined (USE_HT32F49041_32QFN)  || defined (USE_HT32F49041_20TSSOP)

    #define LIBCFG_FLASH_SIZE               (LIBCFG_FLASH_PAGESIZE * 64)
    #define USE_HT32F49041
#endif

#ifndef USE_STDPERIPH_DRIVER
/**
  * @brief comment the line below if you will not use the peripherals drivers.
  * in this case, these drivers will not be included and the application code will
  * be based on direct access to peripherals registers
  */
  #ifdef _RTE_
    #include "RTE_Components.h"
    #ifdef RTE_DEVICE_STDPERIPH_FRAMEWORK
      #define USE_STDPERIPH_DRIVER
    #endif
  #endif
#endif

/**
  * @brief ht32f490x1 standard peripheral library version number
  */
#define HT32_FWLIB_VER                  (0x01001004)
#define HT32_FWLIB_SVN                  (0x146)

/**
  * @}
  */

/** @addtogroup Configuration_section_for_CMSIS
  * @{
  */

/**
  * @brief configuration of the cortex-m4 processor and core peripherals
  */
#define __CM4_REV                 0x0001U  /*!< core revision r0p1                           */
#define __MPU_PRESENT             1        /*!< mpu present                                  */
#define __NVIC_PRIO_BITS          4        /*!< ht32 uses 4 bits for the priority levels     */
#define __Vendor_SysTickConfig    0        /*!< set to 1 if different systick config is used */
#define __FPU_PRESENT             0U       /*!< fpu present                                  */

/**
  * @brief ht32f490x1 interrupt number definition, according to the selected device
  *        in @ref Library_configuration_section
  */
typedef enum IRQn
{
    /******  cortex-m4 processor exceptions numbers ***************************************************/
    Reset_IRQn                  = -15,    /*!< 1 reset vector, invoked on power up and warm reset   */
    NonMaskableInt_IRQn         = -14,    /*!< 2 non maskable interrupt                             */
    HardFault_IRQn              = -13,    /*!< 3 hard fault, all classes of fault                   */
    MemoryManagement_IRQn       = -12,    /*!< 4 cortex-m4 memory management interrupt              */
    BusFault_IRQn               = -11,    /*!< 5 cortex-m4 bus fault interrupt                      */
    UsageFault_IRQn             = -10,    /*!< 6 cortex-m4 usage fault interrupt                    */
    SVCall_IRQn                 = -5,     /*!< 11 cortex-m4 sv call interrupt                       */
    DebugMonitor_IRQn           = -4,     /*!< 12 cortex-m4 debug monitor interrupt                 */
    PendSV_IRQn                 = -2,     /*!< 14 cortex-m4 pend sv interrupt                       */
    SysTick_IRQn                = -1,     /*!< 15 cortex-m4 system tick interrupt                   */

    /******  ht32 specific interrupt numbers *********************************************************/
    WWDT_IRQn                   = 0,      /*!< window watchdog timer interrupt                      */
    PVM_IRQn                    = 1,      /*!< pvm through exint line detection interrupt           */
    ERTC_IRQn                   = 2,      /*!< ertc global interrupt                                */
    FLASH_IRQn                  = 3,      /*!< flash global interrupt                               */
    CRM_IRQn                    = 4,      /*!< crm global interrupt                                 */
    EXINT1_0_IRQn               = 5,      /*!< external line1~0 interrupt                           */
    EXINT3_2_IRQn               = 6,      /*!< external line3~2 interrupt                           */
    EXINT15_4_IRQn              = 7,      /*!< external line15~4 interrupt                          */

    ACC_IRQn                    = 8,      /*!< acc interrupt                                        */
    DMA1_Channel1_IRQn          = 9,      /*!< dma1 channel 1 global interrupt                      */
    DMA1_Channel3_2_IRQn        = 10,     /*!< dma1 channel 3~2 global interrupt                    */
    DMA1_Channel7_4_IRQn        = 11,     /*!< dma1 channel 7~4 global interrupt                    */
    ADC1_IRQn                   = 12,     /*!< adc1 global interrupt                                */
    TMR1_BRK_OVF_TRG_HALL_IRQn  = 13,     /*!< tmr1 brake overflow trigger and hall interrupt       */
    TMR1_CH_IRQn                = 14,     /*!< tmr1 channel interrupt                               */
    TMR2_GLOBAL_IRQn            = 15,     /*!< tmr2 channel interrupt                               */
    TMR3_GLOBAL_IRQn            = 16,     /*!< tmr3 global interrupt                                */
    TMR6_GLOBAL_IRQn            = 17,     /*!< tmr6 global interrupt                                */
    TMR7_GLOBAL_IRQn            = 18,     /*!< tmr7 channel interrupt                               */
    TMR14_GLOBAL_IRQn           = 19,     /*!< tmr14 global interrupt                               */
    TMR15_GLOBAL_IRQn           = 20,     /*!< tmr15 global interrupt                               */
    TMR16_GLOBAL_IRQn           = 21,     /*!< tmr16 global interrupt                               */
    TMR17_GLOBAL_IRQn           = 22,     /*!< tmr17 global interrupt                               */
    I2C1_EVT_IRQn               = 23,     /*!< i2c1 event interrupt                                 */
    I2C2_EVT_IRQn               = 24,     /*!< i2c2 event interrupt                                 */
    SPI1_IRQn                   = 25,     /*!< spi1 global interrupt                                */
    SPI2_IRQn                   = 26,     /*!< spi2 global interrupt                                */
    USART1_IRQn                 = 27,     /*!< usart1 global interrupt                              */
    USART2_IRQn                 = 28,     /*!< usart2 global interrupt                              */
    USART4_3_IRQn               = 29,     /*!< usart3 & usart4 global interrupt                     */
    CAN1_IRQn                   = 30,     /*!< can1 global interrupt                                */
    OTGFS1_IRQn                 = 31,     /*!< otgfs1 global interrupt                              */
    I2C1_ERR_IRQn               = 32,     /*!< i2c1 error interrupt                                 */
    SPI3_IRQn                   = 33,     /*!< spi3 global interrupt                                */
    I2C2_ERR_IRQn               = 34,     /*!< i2c2 error interrupt                                 */
    TMR13_GLOBAL_IRQn           = 35      /*!< tmr13 global interrupt                               */

} IRQn_Type;

/**
  * @}
  */

#include "core_cm4.h"
#include "system_ht32f490x1.h"
#include <stdint.h>

/** @addtogroup Exported_types
  * @{
  */

typedef int32_t  INT32;
typedef int16_t  INT16;
typedef int8_t   INT8;
typedef uint32_t UINT32;
typedef uint16_t UINT16;
typedef uint8_t  UINT8;

typedef int32_t  s32;
typedef int16_t  s16;
typedef int8_t   s8;

typedef const int32_t sc32;   /*!< read only */
typedef const int16_t sc16;   /*!< read only */
typedef const int8_t  sc8;    /*!< read only */

typedef __IO int32_t  vs32;
typedef __IO int16_t  vs16;
typedef __IO int8_t   vs8;

typedef __I int32_t vsc32;    /*!< read only */
typedef __I int16_t vsc16;    /*!< read only */
typedef __I int8_t  vsc8;     /*!< read only */

typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t  u8;

typedef const uint32_t uc32;  /*!< read only */
typedef const uint16_t uc16;  /*!< read only */
typedef const uint8_t  uc8;   /*!< read only */

typedef __IO uint32_t vu32;
typedef __IO uint16_t vu16;
typedef __IO uint8_t  vu8;

typedef __I uint32_t vuc32;   /*!< read only */
typedef __I uint16_t vuc16;   /*!< read only */
typedef __I uint8_t  vuc8;    /*!< read only */

/**
  * @brief flag status
  */
typedef enum {RESET = 0, SET = !RESET} flag_status;

/**
  * @brief confirm state
  */
typedef enum {FALSE = 0, TRUE = !FALSE} confirm_state;

#if !defined(bool) && !defined(__cplusplus) // user may already included <stdbool.h> or CPP
#define bool confirm_state
#define false FALSE
#define true  TRUE
#endif

/**
  * @brief error status
  */
typedef enum {ERROR = 0, SUCCESS = !ERROR} error_status;

/**
  * @}
  */
#if defined (__CC_ARM)
  #define __ALIGN4 __align(4)
#elif defined (__ICCARM__)
  #define __ALIGN4 _Pragma("data_alignment = 4")
#elif defined (__GNUC__)
  #define __ALIGN4  __attribute__((aligned(4)))
#endif

#if defined (__GNUC__)
  #define __PACKED_H
  #define __PACKED_F __attribute__ ((packed))
#elif defined (__ICCARM__) || (__CC_ARM)
  #define __PACKED_H __packed
  #define __PACKED_F
#endif

/**
  * @}
  */

/** @addtogroup Exported_macro
  * @{
  */
#define wb(addr, value)     (*((u8  volatile *) (addr)) = value)
#define rb(addr)            (*((u8  volatile *) (addr)))
#define whw(addr, value)    (*((u16 volatile *) (addr)) = value)
#define rhw(addr)           (*((u16 volatile *) (addr)))
#define ww(addr, value)     (*((u32 volatile *) (addr)) = value)
#define rw(addr)            (*((u32 volatile *) (addr)))

#define REG8(addr)                       *(volatile uint8_t *)(addr)
#define REG16(addr)                      *(volatile uint16_t *)(addr)
#define REG32(addr)                      *(volatile uint32_t *)(addr)

#define MAKE_VALUE(reg_offset, bit_num)  (uint32_t)(((reg_offset) << 16) | (bit_num & 0x1F))

#define PERIPH_REG(periph_base, value)   REG32((periph_base + (value >> 16)))
#define PERIPH_REG_BIT(value)            (0x1U << (value & 0x1F))
#define STRCAT2_(a, b)       a##b
#define STRCAT2(a, b)        STRCAT2_(a, b)

/**
  * @}
  */

/** @addtogroup Peripheral_memory_map
  * @{
  */

#define FLASH_BASE                       ((uint32_t)0x08000000)
#define USD_BASE                         ((uint32_t)0x1FFFF800)
#define SRAM_BASE                        ((uint32_t)0x20000000)
#define PERIPH_BASE                      ((uint32_t)0x40000000)
#define DEBUG_BASE                       ((uint32_t)0xE0042000)

#define APB1PERIPH_BASE                  (PERIPH_BASE + 0x00000)
#define APB2PERIPH_BASE                  (PERIPH_BASE + 0x10000)
#define AHBPERIPH1_BASE                  (PERIPH_BASE + 0x20000)
#define AHBPERIPH2_BASE                  (PERIPH_BASE + 0x8000000)

/* apb1 bus base address */
#define TMR2_BASE                        (APB1PERIPH_BASE + 0x0000)
#define TMR3_BASE                        (APB1PERIPH_BASE + 0x0400)
#define TMR6_BASE                        (APB1PERIPH_BASE + 0x1000)
#define TMR7_BASE                        (APB1PERIPH_BASE + 0x1400)
#define TMR13_BASE                       (APB1PERIPH_BASE + 0x1C00)
#define TMR14_BASE                       (APB1PERIPH_BASE + 0x2000)
#define ERTC_BASE                        (APB1PERIPH_BASE + 0x2800)
#define WWDT_BASE                        (APB1PERIPH_BASE + 0x2C00)
#define WDT_BASE                         (APB1PERIPH_BASE + 0x3000)
#define SPI2_BASE                        (APB1PERIPH_BASE + 0x3800)
#define SPI3_BASE                        (APB1PERIPH_BASE + 0x3C00)
#define USART2_BASE                      (APB1PERIPH_BASE + 0x4400)
#define USART3_BASE                      (APB1PERIPH_BASE + 0x4800)
#define USART4_BASE                      (APB1PERIPH_BASE + 0x4C00)
#define I2C1_BASE                        (APB1PERIPH_BASE + 0x5400)
#define I2C2_BASE                        (APB1PERIPH_BASE + 0x5800)
#define CAN1_BASE                        (APB1PERIPH_BASE + 0x6400)
#define ACC_BASE                         (APB1PERIPH_BASE + 0x6C00)
#define PWC_BASE                         (APB1PERIPH_BASE + 0x7000)
/* apb2 bus base address */
#define SCFG_BASE                        (APB2PERIPH_BASE + 0x0000)
#define EXINT_BASE                       (APB2PERIPH_BASE + 0x0400)
#define ADC1_BASE                        (APB2PERIPH_BASE + 0x2400)
#define TMR1_BASE                        (APB2PERIPH_BASE + 0x2C00)
#define SPI1_BASE                        (APB2PERIPH_BASE + 0x3000)
#define USART1_BASE                      (APB2PERIPH_BASE + 0x3800)
#define TMR15_BASE                       (APB2PERIPH_BASE + 0x4000)
#define TMR16_BASE                       (APB2PERIPH_BASE + 0x4400)
#define TMR17_BASE                       (APB2PERIPH_BASE + 0x4800)
/* ahb bus base address */
#define DMA1_BASE                        (AHBPERIPH1_BASE + 0x0000)
#define DMA1_CHANNEL1_BASE               (AHBPERIPH1_BASE + 0x0008)
#define DMA1_CHANNEL2_BASE               (AHBPERIPH1_BASE + 0x001C)
#define DMA1_CHANNEL3_BASE               (AHBPERIPH1_BASE + 0x0030)
#define DMA1_CHANNEL4_BASE               (AHBPERIPH1_BASE + 0x0044)
#define DMA1_CHANNEL5_BASE               (AHBPERIPH1_BASE + 0x0058)
#define DMA1_CHANNEL6_BASE               (AHBPERIPH1_BASE + 0x006C)
#define DMA1_CHANNEL7_BASE               (AHBPERIPH1_BASE + 0x0080)
#define CRM_BASE                         (AHBPERIPH1_BASE + 0x1000)
#define FLASH_REG_BASE                   (AHBPERIPH1_BASE + 0x2000)
#define CRC_BASE                         (AHBPERIPH1_BASE + 0x3000)
#define GPIOA_BASE                       (AHBPERIPH2_BASE + 0x0000)
#define GPIOB_BASE                       (AHBPERIPH2_BASE + 0x0400)
#define GPIOC_BASE                       (AHBPERIPH2_BASE + 0x0800)
#define GPIOD_BASE                       (AHBPERIPH2_BASE + 0x0C00)
#define GPIOF_BASE                       (AHBPERIPH2_BASE + 0x1400)
#define OTGFS1_BASE                      (PERIPH_BASE + 0x10000000)

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#include "ht32f490x1_def.h"
#include "ht32f490x1_conf.h"

#ifdef __cplusplus
}
#endif

#endif
