/*********************************************************************************************************//**
 * @file    DAC/TMTrigger_PDMA/ht32_board_config.h
 * @version $Rev:: 606          $
 * @date    $Date:: 2026-11-05 #$
 * @brief   The header file of board configuration.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/
/* Define to prevent recursive inclusion -------------------------------------------------------------------*/
#ifndef __HT32_BOARD_CONFIG_H
#define __HT32_BOARD_CONFIG_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Settings ------------------------------------------------------------------------------------------------*/
#if (LIBCFG_DAC0)
#else
  #error "This example code does not apply to the chip you selected."
#endif

  #define HTCFG_DAC_IPN                           DAC0

#if defined(USE_HT32F72388_SK)
  #define _HTCFG_DAC_GPIOX                        C
  #define _HTCFG_DAC_GPION                        3
  #define _HTCFG_DAC_CHN                          0

  #define  HTCFG_TM_IPN                           MCTM0

  #define  HTCFG_PDMA_PORT                        HT_PDMA
#endif

#define HTCFG_DAC_GPIO_ID                         STRCAT2(GPIO_P,         _HTCFG_DAC_GPIOX)
#define HTCFG_DAC_AFIO_PIN                        STRCAT2(AFIO_PIN_,      _HTCFG_DAC_GPION)
#define HTCFG_DAC_CH                              STRCAT2(DAC_CH,         _HTCFG_DAC_CHN)

#define HTCFG_DAC_PORT                            STRCAT2(HT_,             HTCFG_DAC_IPN)
#define HTCFG_DAC_AFIO_MODE                       STRCAT2(AFIO_FUN_,       HTCFG_DAC_IPN)

#define HTCFG_TM_PORT                             STRCAT2(HT_,             HTCFG_TM_IPN)
#define HTCFG_DAC_TRIG_TM                         STRCAT3(DAC_TRIG_,       HTCFG_TM_IPN, _MTO)

#define HTCFG_DAC_PDMA_CH                         STRCAT2(PDMA_DAC0_CH,   _HTCFG_DAC_CHN)

#ifdef __cplusplus
}
#endif

#endif
