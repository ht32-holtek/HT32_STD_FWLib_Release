/*********************************************************************************************************//**
 * @file    CRC/CRC-32/main.c
 * @version $Rev:: 438          $
 * @date    $Date:: 2024-07-01 #$
 * @brief   Main program.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup CRC_Examples CRC
  * @{
  */

/** @addtogroup CRC_32 CRC-32
  * @{
  */


/* Private function prototypes -----------------------------------------------------------------------------*/
u8 rbit_byte(u8 in);
u32 crc32_fast(u32 crc, u8 *buffer, u32 length);

void CKCU_Configuration(void);
void test_fun1(void);
void test_fun2(void);
void test_fun3(void);
void test_fun4(void);
void CRC_Configuration(void);
void PDMA_Configuration(void);

/* Private variables ---------------------------------------------------------------------------------------*/
  u32 seed = 0x0000;
  unsigned int SW_sum, HW_sum;
  u8 crc_dat[9] = {'1','2','3','4','5','6','7','8','9'};
  u8 i, crc_dat_reverse[9];

/* CRC table for the CRC-32. The poly is 0x04C11DB7
   (x^32 + x^26 + x^23 + x^22 + x^16 + x^12 + x^11 + x^10 + x^8 + x^7 + x^5 + x^4 + x^2 + x + 1) */
const u32 crc32_table[256] =
{
  0x00000000, 0x04c11db7, 0x09823b6e, 0x0d4326d9, 0x130476dc, 0x17c56b6b, 0x1a864db2, 0x1e475005,
  0x2608edb8, 0x22c9f00f, 0x2f8ad6d6, 0x2b4bcb61, 0x350c9b64, 0x31cd86d3, 0x3c8ea00a, 0x384fbdbd,
  0x4c11db70, 0x48d0c6c7, 0x4593e01e, 0x4152fda9, 0x5f15adac, 0x5bd4b01b, 0x569796c2, 0x52568b75,
  0x6a1936c8, 0x6ed82b7f, 0x639b0da6, 0x675a1011, 0x791d4014, 0x7ddc5da3, 0x709f7b7a, 0x745e66cd,
  0x9823b6e0, 0x9ce2ab57, 0x91a18d8e, 0x95609039, 0x8b27c03c, 0x8fe6dd8b, 0x82a5fb52, 0x8664e6e5,
  0xbe2b5b58, 0xbaea46ef, 0xb7a96036, 0xb3687d81, 0xad2f2d84, 0xa9ee3033, 0xa4ad16ea, 0xa06c0b5d,
  0xd4326d90, 0xd0f37027, 0xddb056fe, 0xd9714b49, 0xc7361b4c, 0xc3f706fb, 0xceb42022, 0xca753d95,
  0xf23a8028, 0xf6fb9d9f, 0xfbb8bb46, 0xff79a6f1, 0xe13ef6f4, 0xe5ffeb43, 0xe8bccd9a, 0xec7dd02d,
  0x34867077, 0x30476dc0, 0x3d044b19, 0x39c556ae, 0x278206ab, 0x23431b1c, 0x2e003dc5, 0x2ac12072,
  0x128e9dcf, 0x164f8078, 0x1b0ca6a1, 0x1fcdbb16, 0x018aeb13, 0x054bf6a4, 0x0808d07d, 0x0cc9cdca,
  0x7897ab07, 0x7c56b6b0, 0x71159069, 0x75d48dde, 0x6b93dddb, 0x6f52c06c, 0x6211e6b5, 0x66d0fb02,
  0x5e9f46bf, 0x5a5e5b08, 0x571d7dd1, 0x53dc6066, 0x4d9b3063, 0x495a2dd4, 0x44190b0d, 0x40d816ba,
  0xaca5c697, 0xa864db20, 0xa527fdf9, 0xa1e6e04e, 0xbfa1b04b, 0xbb60adfc, 0xb6238b25, 0xb2e29692,
  0x8aad2b2f, 0x8e6c3698, 0x832f1041, 0x87ee0df6, 0x99a95df3, 0x9d684044, 0x902b669d, 0x94ea7b2a,
  0xe0b41de7, 0xe4750050, 0xe9362689, 0xedf73b3e, 0xf3b06b3b, 0xf771768c, 0xfa325055, 0xfef34de2,
  0xc6bcf05f, 0xc27dede8, 0xcf3ecb31, 0xcbffd686, 0xd5b88683, 0xd1799b34, 0xdc3abded, 0xd8fba05a,
  0x690ce0ee, 0x6dcdfd59, 0x608edb80, 0x644fc637, 0x7a089632, 0x7ec98b85, 0x738aad5c, 0x774bb0eb,
  0x4f040d56, 0x4bc510e1, 0x46863638, 0x42472b8f, 0x5c007b8a, 0x58c1663d, 0x558240e4, 0x51435d53,
  0x251d3b9e, 0x21dc2629, 0x2c9f00f0, 0x285e1d47, 0x36194d42, 0x32d850f5, 0x3f9b762c, 0x3b5a6b9b,
  0x0315d626, 0x07d4cb91, 0x0a97ed48, 0x0e56f0ff, 0x1011a0fa, 0x14d0bd4d, 0x19939b94, 0x1d528623,
  0xf12f560e, 0xf5ee4bb9, 0xf8ad6d60, 0xfc6c70d7, 0xe22b20d2, 0xe6ea3d65, 0xeba91bbc, 0xef68060b,
  0xd727bbb6, 0xd3e6a601, 0xdea580d8, 0xda649d6f, 0xc423cd6a, 0xc0e2d0dd, 0xcda1f604, 0xc960ebb3,
  0xbd3e8d7e, 0xb9ff90c9, 0xb4bcb610, 0xb07daba7, 0xae3afba2, 0xaafbe615, 0xa7b8c0cc, 0xa379dd7b,
  0x9b3660c6, 0x9ff77d71, 0x92b45ba8, 0x9675461f, 0x8832161a, 0x8cf30bad, 0x81b02d74, 0x857130c3,
  0x5d8a9099, 0x594b8d2e, 0x5408abf7, 0x50c9b640, 0x4e8ee645, 0x4a4ffbf2, 0x470cdd2b, 0x43cdc09c,
  0x7b827d21, 0x7f436096, 0x7200464f, 0x76c15bf8, 0x68860bfd, 0x6c47164a, 0x61043093, 0x65c52d24,
  0x119b4be9, 0x155a565e, 0x18197087, 0x1cd86d30, 0x029f3d35, 0x065e2082, 0x0b1d065b, 0x0fdc1bec,
  0x3793a651, 0x3352bbe6, 0x3e119d3f, 0x3ad08088, 0x2497d08d, 0x2056cd3a, 0x2d15ebe3, 0x29d4f654,
  0xc5a92679, 0xc1683bce, 0xcc2b1d17, 0xc8ea00a0, 0xd6ad50a5, 0xd26c4d12, 0xdf2f6bcb, 0xdbee767c,
  0xe3a1cbc1, 0xe760d676, 0xea23f0af, 0xeee2ed18, 0xf0a5bd1d, 0xf464a0aa, 0xf9278673, 0xfde69bc4,
  0x89b8fd09, 0x8d79e0be, 0x803ac667, 0x84fbdbd0, 0x9abc8bd5, 0x9e7d9662, 0x933eb0bb, 0x97ffad0c,
  0xafb010b1, 0xab710d06, 0xa6322bdf, 0xa2f33668, 0xbcb4666d, 0xb8757bda, 0xb5365d03, 0xb1f740b4
};

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
  * @brief  Main program.
  * @retval None
  ***********************************************************************************************************/
int main(void)
{
  CKCU_Configuration();

  RETARGET_Configuration();           /* Retarget Related configuration                                     */

  printf("\r\n[CRC-32]");
  /* CRC-32
   * width:   32-bit
   * poly:    0x4C11DB7
   * seed:    0xFFFFFFFF
   * XOROut:  0xFFFFFFFF
   * RefIn:   Yes
   * RefOut:  Yes
   */

  /* SW CRC                                                                                                 */
  test_fun1();

  /* HW1 CRC, move data by CPU                                                                              */
  test_fun2();

  /* HW2 CRC, move data by CPU                                                                              */
  test_fun3();

  #if (LIBCFG_PDMA)
  /* HW3 CRC, move data by PDMA                                                                             */
  test_fun4();
  #endif

  while (1);
}

/*********************************************************************************************************//**
  * @brief  Configure the system clocks.
  * @retval None
  ***********************************************************************************************************/
void CKCU_Configuration(void)
{
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
  /* Enable CRC and PDMA Peripheral clock                                                                   */
  CKCUClock.Bit.PDMA       = 1;
  CKCUClock.Bit.CRC        = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);
}

/*********************************************************************************************************//**
  * @brief  SW CRC, move data by software.
  * @retval None
  ***********************************************************************************************************/
void test_fun1(void)
{
  printf("\r\n>  SW: ");

  for (i = 0; i < sizeof(crc_dat); i++)
  {
    crc_dat_reverse[i] = rbit_byte(crc_dat[i]);
  }

  SW_sum = crc32_fast(seed, crc_dat_reverse, sizeof(crc_dat_reverse));
  SW_sum = RBIT(SW_sum) ^ 0xFFFFFFFF;
  printf("sum = 0x%08X", SW_sum);
}

/*********************************************************************************************************//**
  * @brief  HW1 CRC, move data by CPU.
  * @retval None
  ***********************************************************************************************************/
void test_fun2(void)
{
  printf("\r\n> HW1: ");

  HW_sum = CRC_32(seed, crc_dat, sizeof(crc_dat));
  printf("sum = 0x%08X", HW_sum);

  #if defined(USE_HT50L3200U)
  printf(" (HT50L3200U use different setting of CRC_32() function!)");
  #endif
}

/*********************************************************************************************************//**
  * @brief  HW2 CRC, move data by CPU.
  * @retval None
  ***********************************************************************************************************/
void test_fun3(void)
{
  printf("\r\n> HW2: ");

  CRC_Configuration();

  CRC_Process(HT_CRC, crc_dat, 5);

  HW_sum = CRC_Process(HT_CRC, crc_dat + 5, 4);
  printf("sum = 0x%04X", HW_sum);
}

#if (LIBCFG_PDMA)
/*********************************************************************************************************//**
  * @brief  HW3 CRC, move data by PDMA.
  * @retval None
  ***********************************************************************************************************/
void test_fun4(void)
{
  printf("\r\n> HW3: ");

  CRC_Configuration();

  PDMA_Configuration();

  PDMA_SwTrigCmd(PDMA_CH0, ENABLE);

  while (PDMA_GetFlagStatus(PDMA_CH0, PDMA_FLAG_TC) == RESET);
  PDMA_ClearFlag(PDMA_CH0, PDMA_FLAG_TC);

  HW_sum = CRC_Process(HT_CRC, NULL, 0);
  printf("sum = 0x%08X", HW_sum);
}
#endif
/*********************************************************************************************************//**
  * @brief  8-bit reverse.
  * @retval None
  ***********************************************************************************************************/
u8 rbit_byte(u8 in)
{
  u32 out = RBIT((u32)in);

  return (u8)(out >> 24);
}

/*********************************************************************************************************//**
  * @brief  crc32_fast.
  * @retval None
  ***********************************************************************************************************/
u32 crc32_fast(u32 crc, u8 *buffer, u32 length)
{
  while (length--)
    crc = crc32_table[((crc >> 24) ^ *buffer++) & 0xFF] ^ (crc << 8);

  return crc;
}

/*********************************************************************************************************//**
  * @brief  Configure the CRC.
  * @retval None
  ***********************************************************************************************************/
void CRC_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  CRC_InitTypeDef CRC_InitStructure;
  CRC_InitStructure.Mode = CRC_32_POLY;
  CRC_InitStructure.uSeed = seed;
  CRC_InitStructure.uCR = 0;
  CRC_Init(HT_CRC, &CRC_InitStructure);
}

#if (LIBCFG_PDMA)
/*********************************************************************************************************//**
  * @brief  Configure the PDMA.
  * @retval None
  ***********************************************************************************************************/
void PDMA_Configuration(void)
{
  /* !!! NOTICE !!!
     Notice that the local variable (structure) did not have an initial value.
     Please confirm that there are no missing members in the parameter settings below in this function.
  */
  PDMACH_InitTypeDef PDMACH_InitStructure;
  PDMACH_InitStructure.PDMACH_SrcAddr   = (u32)crc_dat;
  PDMACH_InitStructure.PDMACH_DstAddr   = (u32)&HT_CRC->DR;
  PDMACH_InitStructure.PDMACH_BlkCnt    = sizeof(crc_dat)/3;
  PDMACH_InitStructure.PDMACH_BlkLen    = 3;
  PDMACH_InitStructure.PDMACH_DataSize  = WIDTH_8BIT;
  PDMACH_InitStructure.PDMACH_Priority  = L_PRIO;
  PDMACH_InitStructure.PDMACH_AdrMod    = (SRC_ADR_LIN_INC | DST_ADR_FIX);
  PDMA_Config(PDMA_CH0, &PDMACH_InitStructure);
  PDMA_IntConfig(PDMA_CH0, (PDMA_INT_GE | PDMA_INT_TC), ENABLE);
  PDMA_EnaCmd(PDMA_CH0, ENABLE);
}
#endif

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
     Example: printf("Parameter Error: file %s on line %d\r\n", filename, uline);
  */

  while (1)
  {
  }
}
#endif


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
