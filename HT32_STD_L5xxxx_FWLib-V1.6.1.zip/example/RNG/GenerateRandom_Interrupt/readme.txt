/**
 @page RNG_GenerateRandom_Interrupt

 @verbatim
 * @file    RNG/GenerateRandom_Interrupt/readme.txt
 * @version V1.00
 * @date    2025-05-15
 * @brief   Description of GenerateRandom_Interrupt example.
 @endverbatim

@par Example Description:

This example shows how to use the RNG (Random Number Generator) in interrupt mode.
A total of 10 random numbers (each 192-bit wide) will be generated and stored
in a predefined buffer using the RNG_GetRandomNumber() function.

@par Directory Contents:

- RNG/GenerateRandom_Interrupt/main.c                  Main program
- RNG/GenerateRandom_Interrupt/ht32lxxxx_nn_it.c       Interrupt handlers

@par Hardware and Software Environment:

- Connect a null-modem female/female RS232 cable between the COM1 connector and PC serial port.
  Hyperterminal configuration:
  - Word Length = 8 Bits
  - One Stop Bit
  - No parity
  - BaudRate = 115200 baud
  - flow control: None

@par Firmware Disclaimer Information

1. The customer hereby acknowledges and agrees that the program technical documentation, including the
   code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
   proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
   other intellectual property laws.

2. The customer hereby acknowledges and agrees that the program technical documentation, including the
   code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
   other than HOLTEK and the customer.

3. The program technical documentation, including the code, is provided "as is" and for customer reference
   only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
   the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
   the warranties of merchantability, satisfactory quality and fitness for a particular purpose.

 * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
 */
